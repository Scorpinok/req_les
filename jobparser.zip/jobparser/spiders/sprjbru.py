import scrapy
from scrapy.http import HtmlResponse
from jobparser.items import JobparserItem

class SprjbruSpider(scrapy.Spider):
    name = 'sprjbru'
    allowed_domains = ['superjob.ru']
    start_urls = ['https://russia.superjob.ru/vacancy/search/?keywords=python']

    def parse(self, response: HtmlResponse):
        next_page = response.xpath("//a[@rel='next']/@href").get()
        if next_page:
            yield response.follow(next_page, callback=self.parse)
        links = response.xpath("//span[@class='_2TI7V _21QHd _36Ys4 _3SmWj']/@href").getall()
        for link in links:
            yield response.follow(link, callback=self.vacancy_parse)

    def vacancy_parse(self, response: HtmlResponse):
        url = response.url
        name = response.xpath("//span[@class='_2TI7V _21QHd _36Ys4 _3SmWj']/a/text()").get()
        salary = response.xpath("//span[@class='_2eYAG _10_Fa _21QHd _36Ys4 _9Is4f']/text()").get()

        yield JobparserItem(name=name, salary=salary, url=url)
