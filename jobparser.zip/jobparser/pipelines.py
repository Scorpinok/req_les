# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from pymongo import MongoClient
import unicodedata

class JobparserPipeline:
    def __init__(self):
        client = MongoClient('localhost', 27017)
        self.mongo_db = client["jobs_db"]
        self.mongo_hh_col = self.mongo_db["hhru_vacs"]
        self.mongo_sprjb_col = self.mongo_db["sprjb_vacs"]

    def process_item(self, item, spider):

        if spider.name == 'sprjbru':
            #item['salary'] = self.process_salary_sprjb(item['salary'])
            self.mongo_sprjb_col.update_one(item, {"$set": item}, upsert=True)
        else:
            item['salary'] = self.process_salary(item['salary'])
            self.mongo_hh_col.update_one(item, {"$set": item}, upsert=True)

        return item

    def process_salary(self, salary):
        if salary[0] == 'з/п не указана':
            sal_min = None
            sal_max = None
            sal_val = None
        elif salary[2] == ' ' and salary[3] != ' ':
            sal_val = salary[3]
            sal_min = unicodedata.normalize("NFKD", salary[1]).replace(' ', '')
            sal_max = None
        else:
            sal_val = salary[5]
            sal_min = unicodedata.normalize("NFKD", salary[1]).replace(' ', '')
            sal_max = unicodedata.normalize("NFKD", salary[3]).replace(' ', '')

        return sal_min, sal_max, sal_val

    def process_salary_sprjb(self, salary):
        sal_min = salary
        sal_max = 1
        sal_val = 'dd'

        return sal_min#, sal_max, sal_val